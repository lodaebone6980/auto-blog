(function(){const p="naviwrite-qr-helper";chrome.storage.local.get("pendingNaverQr",t=>{const e=t.pendingNaverQr;!(e!=null&&e.targetUrl)||!location.hostname.includes("qr.naver.com")||h(e)});function h(t){var n,r,i,a,l;if(document.getElementById(p))return;const e=document.createElement("div");e.id=p,e.style.cssText=`
    position: fixed;
    right: 18px;
    top: 18px;
    z-index: 2147483647;
    width: 340px;
    padding: 16px;
    border: 1px solid #d9e2ec;
    border-radius: 14px;
    background: #ffffff;
    box-shadow: 0 12px 36px rgba(15, 23, 42, 0.18);
    color: #1f2937;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans KR", sans-serif;
  `,e.innerHTML=`
    <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px;">
      <strong style="font-size:15px;color:#1B3A5C;">NaviWrite 네이버 QR</strong>
      <button id="naviwrite-qr-close" style="border:0;background:#f3f4f6;border-radius:8px;padding:4px 8px;cursor:pointer;">닫기</button>
    </div>
    <div style="font-size:12px;line-height:1.55;color:#4b5563;margin-bottom:12px;">
      <div><b>QR 이름</b>: ${m(t.qrName||"")}</div>
      <div style="word-break:break-all;"><b>연결 링크</b>: ${m(t.targetUrl)}</div>
    </div>
    <div id="naviwrite-qr-status" style="font-size:12px;color:#6b7280;margin-bottom:12px;">
      코드 생성 화면에서 자동 입력을 시도할 수 있습니다.
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
      <button id="naviwrite-qr-create" style="${u("#1B3A5C")}">코드 생성 찾기</button>
      <button id="naviwrite-qr-fill" style="${u("#2E75B6")}">자동 입력</button>
      <button id="naviwrite-qr-copy" style="${u("#64748b")}">링크 복사</button>
      <button id="naviwrite-qr-save" style="${u("#2E8B57")}">완료 저장</button>
    </div>
    <p style="font-size:11px;line-height:1.45;color:#9ca3af;margin-top:10px;">
      네이버 로그인은 사용자가 직접 진행합니다. 비밀번호는 저장하지 않습니다.
    </p>
  `,document.documentElement.appendChild(e),(n=s("#naviwrite-qr-close"))==null||n.addEventListener("click",()=>e.remove()),(r=s("#naviwrite-qr-create"))==null||r.addEventListener("click",()=>{g(["코드 생성","QR코드 만들기","만들기"])}),(i=s("#naviwrite-qr-fill"))==null||i.addEventListener("click",()=>w(t)),(a=s("#naviwrite-qr-copy"))==null||a.addEventListener("click",async()=>{await navigator.clipboard.writeText(t.targetUrl),c("연결 링크를 클립보드에 복사했습니다.")}),(l=s("#naviwrite-qr-save"))==null||l.addEventListener("click",()=>E(t))}function w(t){g(["URL 링크","URL","링크로 이동","웹사이트"]);const e=b(["제목","코드명","코드 이름","이름","title","name"],t.qrName||t.keyword||"NaviWrite QR"),n=b(["URL","주소","링크","url","link"],t.targetUrl,!0);c(`자동 입력 시도 완료: QR 이름 ${e?"성공":"확인 필요"}, 연결 링크 ${n?"성공":"확인 필요"}`)}function b(t,e,n=!1){const r=Array.from(document.querySelectorAll("input, textarea")).filter(A),i=n?r.find(o=>o instanceof HTMLInputElement&&o.type==="url"):null;if(i)return d(i,e),!0;const a=r.find(o=>{var f;const y=[o.getAttribute("placeholder"),o.getAttribute("aria-label"),o.getAttribute("name"),o.getAttribute("id"),(f=o.closest("label"))==null?void 0:f.textContent,L(o)].filter(Boolean).join(" ").toLowerCase();return t.some(x=>y.includes(x.toLowerCase()))});if(a)return d(a,e),!0;const l=r.find(o=>o instanceof HTMLInputElement?["text","search","url",""].includes(o.type):!0);return l?(d(l,e),!0):!1}function E(t){const e=q(),n=location.href;if(!t.jobId){c("작업 ID가 없어 서버 저장은 건너뛰었습니다. QR 이미지는 수동으로 저장해 주세요.");return}chrome.runtime.sendMessage({type:"UPDATE_CONTENT_JOB_QR",payload:{jobId:t.jobId,naverQrImageUrl:e,naverQrManageUrl:n}},r=>{if(chrome.runtime.lastError){c(`저장 실패: ${chrome.runtime.lastError.message}`);return}if(r!=null&&r.error){c(`저장 실패: ${r.error}`);return}c("QR 정보가 DB와 Google Sheets 동기화 대상으로 저장되었습니다.")})}function q(){const e=Array.from(document.querySelectorAll("img")).find(r=>{const i=r.src||"",a=r.alt||"",l=`${i} ${a}`.toLowerCase();return r.width>=80&&r.height>=80&&(l.includes("qr")||l.includes("code"))});if(e!=null&&e.src)return e.src;const n=Array.from(document.querySelectorAll("canvas")).find(r=>r.width>=80&&r.height>=80);if(n)try{return n.toDataURL("image/png")}catch{return null}return null}function g(t){const n=Array.from(document.querySelectorAll("a, button, [role='button'], label, span, div")).filter(v).find(r=>{const i=(r.textContent||"").replace(/\s+/g," ").trim();return t.some(a=>i.includes(a))});return n?(n.click(),c(`${(n.textContent||"대상").trim()} 항목을 선택했습니다.`),!0):(c(`${t.join(" / ")} 버튼을 찾지 못했습니다. 화면에서 직접 선택해 주세요.`),!1)}function d(t,e){var i;const n=t instanceof HTMLInputElement?HTMLInputElement.prototype:HTMLTextAreaElement.prototype,r=(i=Object.getOwnPropertyDescriptor(n,"value"))==null?void 0:i.set;r==null||r.call(t,e),t.dispatchEvent(new Event("input",{bubbles:!0})),t.dispatchEvent(new Event("change",{bubbles:!0}))}function L(t){var n;const e=t.getAttribute("id");return e&&((n=document.querySelector(`label[for="${CSS.escape(e)}"]`))==null?void 0:n.textContent)||""}function A(t){return t.disabled||t.readOnly?!1:v(t)}function v(t){const e=t.getBoundingClientRect(),n=getComputedStyle(t);return e.width>0&&e.height>0&&n.visibility!=="hidden"&&n.display!=="none"}function s(t){return document.querySelector(t)}function c(t){const e=s("#naviwrite-qr-status");e&&(e.textContent=t)}function u(t){return["border:0","border-radius:9px","padding:9px 8px",`background:${t}`,"color:white","font-size:12px","font-weight:700","cursor:pointer"].join(";")}function m(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}
})()
