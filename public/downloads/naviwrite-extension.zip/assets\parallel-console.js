(() => {
  const DEFAULT_SERVER = 'https://web-production-184ff.up.railway.app';
  const DEFAULT_RUNNER = 'http://127.0.0.1:39271';
  const state = {
    open: false,
    running: false,
    progress: 0,
    settings: {},
    rows: [],
    message: '',
    messageType: 'ok',
    progressTimer: null,
  };

  const $ = (selector) => document.querySelector(selector);

  function nowText() {
    return new Date().toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' });
  }

  function storageGet(key) {
    return new Promise((resolve) => {
      try {
        if (typeof chrome !== 'undefined' && chrome.storage?.sync) {
          chrome.storage.sync.get(key, (value) => resolve(value?.[key] || {}));
          return;
        }
      } catch {}
      resolve({});
    });
  }

  function storageSet(key, value) {
    return new Promise((resolve) => {
      try {
        if (typeof chrome !== 'undefined' && chrome.storage?.sync) {
          chrome.storage.sync.set({ [key]: value }, resolve);
          return;
        }
      } catch {}
      resolve();
    });
  }

  function apiBase() {
    const raw = String(state.settings.serverUrl || DEFAULT_SERVER).replace(/\/$/, '');
    return /\/api$/i.test(raw) ? raw : `${raw}/api`;
  }

  function runnerBase() {
    return String(state.settings.runnerUrl || DEFAULT_RUNNER).replace(/\/$/, '');
  }

  async function fetchJson(url, options = {}) {
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {}),
      },
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || payload.message || `요청 실패 (${response.status})`);
    return payload;
  }

  function parseKeywords(raw) {
    return [...new Set(String(raw || '')
      .split(/\r?\n|,/)
      .map((item) => item.trim())
      .filter(Boolean))]
      .slice(0, 50);
  }

  function rowTemplate(row) {
    const icon = row.status === 'done' ? '✓' : row.status === 'error' ? '!' : row.status === 'running' ? '●' : '·';
    const statusClass = row.status === 'done' ? 'is-done' : row.status === 'error' ? 'is-error' : row.status === 'running' ? 'is-running' : '';
    return `
      <div class="nw-step ${statusClass}" data-keyword="${escapeHtml(row.keyword)}">
        <div class="nw-step-icon">${icon}</div>
        <div>
          <p class="nw-step-title">${escapeHtml(row.keyword)}</p>
          <p class="nw-step-desc">${escapeHtml(row.desc || '대기중')}</p>
        </div>
        <span class="nw-step-time">${escapeHtml(row.time || '')}</span>
      </div>
    `;
  }

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function renderRows() {
    const list = $('#nwParallelRows');
    if (!list) return;
    list.innerHTML = state.rows.length
      ? state.rows.map(rowTemplate).join('')
      : '<p class="nw-muted">키워드를 입력하고 전체 자동화 시작을 누르면 단계별 진행 상황이 여기에 표시됩니다.</p>';
  }

  function setMessage(message, type = 'ok') {
    state.message = message;
    state.messageType = type;
    const el = $('#nwParallelMessage');
    if (!el) return;
    el.textContent = message || '';
    el.className = `nw-message ${message ? 'is-show' : ''} ${type === 'error' ? 'is-error' : 'is-ok'}`;
  }

  function setProgress(value) {
    state.progress = Math.max(0, Math.min(100, Number(value) || 0));
    const bar = $('#nwParallelProgressBar');
    const percent = $('#nwParallelProgressPercent');
    if (bar) bar.style.width = `${state.progress}%`;
    if (percent) percent.textContent = `${Math.round(state.progress)}%`;
  }

  function updateSummary() {
    const keywords = parseKeywords($('#nwParallelKeywords')?.value || '');
    const concurrency = Number($('#nwParallelConcurrency')?.value || 3);
    const summary = $('#nwParallelSummaryMeta');
    if (summary) {
      summary.textContent = `키워드 ${keywords.length}개 · 병렬 ${concurrency}개 · ${$('#nwParallelPlatform')?.value || 'blog'}`;
    }
  }

  function setRunning(running) {
    state.running = running;
    const button = $('#nwParallelStart');
    if (button) {
      button.disabled = running;
      button.textContent = running ? '병렬 자동화 진행 중...' : '전체 자동화 시작';
    }
  }

  function markAll(status, desc) {
    state.rows = state.rows.map((row) => ({ ...row, status, desc, time: nowText() }));
    renderRows();
  }

  function markFromJobs(jobs = []) {
    const byKeyword = new Map();
    jobs.forEach((job) => {
      const key = String(job.target_keyword || job.keyword || '').trim();
      if (key) byKeyword.set(key, job);
    });
    state.rows = state.rows.map((row) => {
      const job = byKeyword.get(row.keyword) || jobs.find((item) => String(item.target_keyword || '').includes(row.keyword));
      if (!job) return { ...row, status: 'done', desc: '초안 생성 완료', time: nowText() };
      if (job.status === '오류') return { ...row, status: 'error', desc: job.error_message || '생성 오류', time: nowText(), rewriteJobId: job.id };
      return { ...row, status: 'done', desc: `초안 생성 완료 #${job.id}`, time: nowText(), rewriteJobId: job.id };
    });
    renderRows();
  }

  async function openDashboard() {
    const target = String(state.settings.serverUrl || DEFAULT_SERVER).replace(/\/$/, '');
    try {
      if (typeof chrome !== 'undefined' && chrome.tabs?.create) {
        chrome.tabs.create({ url: target });
      } else {
        window.open(target, '_blank');
      }
    } catch {
      window.open(target, '_blank');
    }
  }

  async function startParallel() {
    const keywords = parseKeywords($('#nwParallelKeywords')?.value || '');
    if (keywords.length === 0) {
      setMessage('포스팅 키워드를 한 줄에 하나씩 입력해 주세요.', 'error');
      return;
    }

    const concurrency = Math.max(1, Math.min(5, Number($('#nwParallelConcurrency')?.value || 3)));
    const platform = $('#nwParallelPlatform')?.value || 'blog';
    const category = $('#nwParallelCategory')?.value || 'IT/테크';
    const ctaUrl = $('#nwParallelCta')?.value.trim() || '';
    const useNaverQr = Boolean($('#nwParallelQr')?.checked);
    const useAiImages = Boolean($('#nwParallelImages')?.checked);
    const pushQueue = Boolean($('#nwParallelQueue')?.checked);
    const pushRunner = Boolean($('#nwParallelRunner')?.checked);
    const spacingMinutes = Math.max(10, Number($('#nwParallelSpacing')?.value || 120));
    const actionDelayMinutes = Math.max(1, Number($('#nwParallelDelay')?.value || 1));

    const saved = {
      keywordsText: keywords.join('\n'),
      concurrency,
      platform,
      category,
      ctaUrl,
      useNaverQr,
      useAiImages,
      pushQueue,
      pushRunner,
      spacingMinutes,
      actionDelayMinutes,
    };
    await storageSet('parallelConsole', saved);

    state.rows = keywords.map((keyword) => ({ keyword, status: 'waiting', desc: '대기중', time: '' }));
    renderRows();
    setMessage('');
    setRunning(true);
    setProgress(4);

    clearInterval(state.progressTimer);
    state.progressTimer = setInterval(() => {
      if (state.progress < 82) setProgress(state.progress + 3);
    }, 1400);

    try {
      markAll('running', `작업 등록 및 병렬 초안 생성 중 · 동시 ${concurrency}개`);
      const rewrite = await fetchJson(`${apiBase()}/rewrite-jobs`, {
        method: 'POST',
        body: JSON.stringify({
          targetKeywords: keywords.join('\n'),
          platform,
          category,
          ctaUrl,
          useNaverQr,
          useAiImages,
          concurrency,
          rewriteSettings: {
            targetCharCount: 2200,
            sectionCharCount: 300,
            sectionCount: 7,
            targetKwCount: 16,
            imageCount: 8,
          },
        }),
      });

      clearInterval(state.progressTimer);
      setProgress(pushQueue ? 76 : 100);
      markFromJobs(rewrite.jobs || []);

      let contentJobs = [];
      if (pushQueue) {
        const rewriteJobIds = (rewrite.jobs || []).map((job) => job.id).filter(Boolean);
        markAll('running', '발행 큐 예약 등록 중');
        const queue = await fetchJson(`${apiBase()}/rewrite-jobs/to-content-jobs/bulk`, {
          method: 'POST',
          body: JSON.stringify({
            rewriteJobIds,
            publishMode: 'scheduled',
            spacingMinutes,
            actionDelayMinutes,
            autoReady: false,
          }),
        });
        contentJobs = queue.jobs || [];
        setProgress(pushRunner ? 90 : 100);
        state.rows = state.rows.map((row, index) => ({
          ...row,
          status: 'done',
          desc: `발행 큐 등록 완료${contentJobs[index]?.id ? ` #${contentJobs[index].id}` : ''}`,
          time: nowText(),
          contentJobId: contentJobs[index]?.id || null,
        }));
        renderRows();
      }

      if (pushRunner && contentJobs.length > 0) {
        const runner = await fetchJson(`${runnerBase()}/publish/queue`, {
          method: 'POST',
          body: JSON.stringify({
            apiBase: apiBase(),
            jobIds: contentJobs.map((job) => job.id).filter(Boolean),
            spacingMinutes,
            actionDelayMinutes,
            concurrency,
          }),
        });
        setProgress(100);
        setMessage(`완료: ${keywords.length}개 키워드 처리, Runner 배치 ${runner.batch?.id || ''} 저장`, 'ok');
      } else {
        setMessage(`완료: ${keywords.length}개 키워드가 병렬 처리되었습니다.`, 'ok');
      }
    } catch (error) {
      clearInterval(state.progressTimer);
      setProgress(Math.max(state.progress, 8));
      state.rows = state.rows.map((row) => row.status === 'running' ? {
        ...row,
        status: 'error',
        desc: error.message || '자동화 실패',
        time: nowText(),
      } : row);
      renderRows();
      setMessage(error.message || '자동화 중 오류가 발생했습니다.', 'error');
    } finally {
      clearInterval(state.progressTimer);
      state.progressTimer = null;
      setRunning(false);
      updateSummary();
    }
  }

  function mount() {
    if ($('#nwParallelShell')) return;
    const launcher = document.createElement('button');
    launcher.id = 'nwParallelLauncher';
    launcher.className = 'nw-parallel-launcher';
    launcher.type = 'button';
    launcher.textContent = '자동화';
    launcher.addEventListener('click', () => setOpen(true));
    document.body.appendChild(launcher);

    const shell = document.createElement('section');
    shell.id = 'nwParallelShell';
    shell.className = 'nw-parallel-shell';
    shell.innerHTML = `
      <header class="nw-parallel-header">
        <div class="nw-parallel-title-row">
          <div>
            <p class="nw-parallel-kicker">NaviWrite Parallel Console</p>
            <h2 class="nw-parallel-title">포스팅 마스터 V7</h2>
          </div>
          <button id="nwParallelClose" class="nw-parallel-close" type="button">×</button>
        </div>
        <div class="nw-parallel-tabs">
          <button class="nw-parallel-tab is-active" type="button">자동화</button>
          <button class="nw-parallel-tab" type="button" id="nwOpenDashboard">포스팅</button>
          <button class="nw-parallel-tab" type="button" id="nwOpenSettings">설정</button>
        </div>
      </header>
      <main class="nw-parallel-body">
        <div id="nwParallelMessage" class="nw-message"></div>
        <section class="nw-card">
          <label class="nw-label" for="nwParallelKeywords">키워드 꾸러미 직접 입력</label>
          <textarea id="nwParallelKeywords" class="nw-textarea" placeholder="안양 꼬치구이 맛집&#10;군포 구인구직 바로가기&#10;sbti 테스트 링크"></textarea>
          <p class="nw-muted" style="margin-top: 6px;">줄바꿈 또는 쉼표로 구분합니다. 서버에서 지정한 병렬수만큼 초안을 동시에 생성합니다.</p>
        </section>
        <section class="nw-card">
          <div class="nw-grid-3">
            <label>
              <span class="nw-label">병렬수</span>
              <input id="nwParallelConcurrency" class="nw-input" type="number" min="1" max="5" value="3">
            </label>
            <label>
              <span class="nw-label">플랫폼</span>
              <select id="nwParallelPlatform" class="nw-select">
                <option value="blog">네이버 블로그</option>
                <option value="cafe">네이버 카페</option>
                <option value="premium">네프콘</option>
                <option value="brunch">브런치</option>
                <option value="wordpress">워드프레스</option>
              </select>
            </label>
            <label>
              <span class="nw-label">카테고리</span>
              <input id="nwParallelCategory" class="nw-input" value="IT/테크">
            </label>
          </div>
          <label style="display:block;margin-top:8px;">
            <span class="nw-label">CTA 링크</span>
            <input id="nwParallelCta" class="nw-input" placeholder="글마다 공통으로 넣을 링크가 있으면 입력">
          </label>
          <div class="nw-check-row">
            <span>네이버 QR 사용</span>
            <input id="nwParallelQr" type="checkbox" checked>
          </div>
          <div class="nw-check-row">
            <span>이미지 생성 포함</span>
            <input id="nwParallelImages" type="checkbox" checked>
          </div>
          <div class="nw-check-row">
            <span>완료 후 발행 큐 예약 등록</span>
            <input id="nwParallelQueue" type="checkbox" checked>
          </div>
          <div class="nw-check-row">
            <span>Local Runner 배치 저장</span>
            <input id="nwParallelRunner" type="checkbox">
          </div>
          <div class="nw-grid-2" style="margin-top:8px;">
            <label>
              <span class="nw-label">글 간격(분)</span>
              <input id="nwParallelSpacing" class="nw-input" type="number" min="10" value="120">
            </label>
            <label>
              <span class="nw-label">액션 딜레이(분)</span>
              <input id="nwParallelDelay" class="nw-input" type="number" min="1" value="1">
            </label>
          </div>
        </section>
        <button id="nwParallelStart" class="nw-start-button" type="button">전체 자동화 시작</button>
        <div class="nw-summary" style="margin-top:10px;">
          <div>
            <p class="nw-summary-title">전체 진행률</p>
            <p id="nwParallelSummaryMeta" class="nw-summary-meta">키워드 0개 · 병렬 3개 · blog</p>
            <div class="nw-progress-wrap"><div id="nwParallelProgressBar" class="nw-progress-bar"></div></div>
          </div>
          <span id="nwParallelProgressPercent" class="nw-progress-percent">0%</span>
        </div>
        <section class="nw-card">
          <div class="nw-step-list" id="nwParallelRows"></div>
        </section>
      </main>
    `;
    document.body.appendChild(shell);

    $('#nwParallelClose')?.addEventListener('click', () => setOpen(false));
    $('#nwParallelStart')?.addEventListener('click', startParallel);
    $('#nwOpenDashboard')?.addEventListener('click', openDashboard);
    $('#nwOpenSettings')?.addEventListener('click', () => {
      setOpen(false);
      const settingsButton = [...document.querySelectorAll('button')].find((button) => button.textContent?.includes('설정'));
      settingsButton?.click();
    });
    ['nwParallelKeywords', 'nwParallelConcurrency', 'nwParallelPlatform'].forEach((id) => {
      $(`#${id}`)?.addEventListener('input', updateSummary);
      $(`#${id}`)?.addEventListener('change', updateSummary);
    });
    renderRows();
    updateSummary();
  }

  async function loadSaved() {
    state.settings = await storageGet('settings');
    const saved = await storageGet('parallelConsole');
    if ($('#nwParallelKeywords') && saved.keywordsText) $('#nwParallelKeywords').value = saved.keywordsText;
    if ($('#nwParallelConcurrency') && saved.concurrency) $('#nwParallelConcurrency').value = saved.concurrency;
    if ($('#nwParallelPlatform') && saved.platform) $('#nwParallelPlatform').value = saved.platform;
    if ($('#nwParallelCategory') && saved.category) $('#nwParallelCategory').value = saved.category;
    if ($('#nwParallelCta') && saved.ctaUrl) $('#nwParallelCta').value = saved.ctaUrl;
    if ($('#nwParallelQr')) $('#nwParallelQr').checked = saved.useNaverQr !== false;
    if ($('#nwParallelImages')) $('#nwParallelImages').checked = saved.useAiImages !== false;
    if ($('#nwParallelQueue')) $('#nwParallelQueue').checked = saved.pushQueue !== false;
    if ($('#nwParallelRunner')) $('#nwParallelRunner').checked = Boolean(saved.pushRunner);
    if ($('#nwParallelSpacing') && saved.spacingMinutes) $('#nwParallelSpacing').value = saved.spacingMinutes;
    if ($('#nwParallelDelay') && saved.actionDelayMinutes) $('#nwParallelDelay').value = saved.actionDelayMinutes;
    updateSummary();
  }

  function setOpen(open) {
    state.open = open;
    $('#nwParallelShell')?.classList.toggle('is-open', open);
  }

  function boot() {
    mount();
    loadSaved();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, { once: true });
  } else {
    boot();
  }
})();
